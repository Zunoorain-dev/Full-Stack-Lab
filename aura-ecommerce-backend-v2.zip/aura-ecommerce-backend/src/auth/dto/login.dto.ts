import { IsEmail, IsString, MinLength } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class LoginDto {
  @ApiProperty({ example: 'alex@aura.store' })
  @IsEmail()
  email: string;

  @ApiProperty({ example: 'DemoPass123!' })
  @IsString()
  @MinLength(6)
  password: string;
}
