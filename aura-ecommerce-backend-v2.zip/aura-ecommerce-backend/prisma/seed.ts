import { PrismaClient, Category } from '@prisma/client';
import * as bcrypt from 'bcrypt';

const prisma = new PrismaClient();

async function main() {
  const hashedPassword = await bcrypt.hash('DemoPass123!', 10);

  const demoUser = await prisma.user.upsert({
    where: { email: 'alex@aura.store' },
    update: {},
    create: {
      fullName: 'Alex Mercer',
      email: 'alex@aura.store',
      password: hashedPassword,
    },
  });

  const productsData = [
    {
      name: 'AURA Studio ANC Headphones',
      description: 'Active noise-canceling wireless over-ear headphones with 40-hour battery.',
      price: 249.00,
      category: Category.ELECTRONICS,
      stock: 35,
      badge: 'Best Seller',
    },
    {
      name: 'Chrono Minimalist Watch',
      description: 'Sapphire crystal glass with brushed titanium casing and Italian leather strap.',
      price: 185.00,
      category: Category.FASHION,
      stock: 28,
      badge: 'New',
    },
    {
      name: 'Nordic Ceramic Pour-Over Set',
      description: 'Hand-glazed stoneware dripper and carafe for specialty coffee brewing.',
      price: 68.00,
      category: Category.HOME_LIVING,
      stock: 42,
      badge: null,
    },
    {
      name: 'MagCharge 3-in-1 Aluminum Dock',
      description: 'CNC-machined magnetic wireless charging stand for phone, watch, and earbuds.',
      price: 119.00,
      category: Category.ELECTRONICS,
      stock: 50,
      badge: 'Trending',
    },
    {
      name: 'Merino Knit Everyday Bomber',
      description: 'Breathable temperature-regulating merino wool blend jacket in charcoal.',
      price: 145.00,
      category: Category.FASHION,
      stock: 20,
      badge: null,
    },
    {
      name: 'Lumina Smart Ambient Lamp',
      description: 'Touch-dimmable warm-to-cool desk lamp with wireless base.',
      price: 89.00,
      category: Category.HOME_LIVING,
      stock: 30,
      badge: 'Top Rated',
    },
    {
      name: 'Full-Grain Tech Folio Organizer',
      description: 'Compact zippered leather organizer for cables, SSDs, and stylus.',
      price: 54.00,
      category: Category.ACCESSORIES,
      stock: 60,
      badge: null,
    },
    {
      name: 'Mechanical Tactile 75% Keyboard',
      description: 'Hot-swappable aluminum wireless mechanical keyboard with PBT keycaps.',
      price: 169.00,
      category: Category.ELECTRONICS,
      stock: 25,
      badge: 'Limited',
    },
  ];

  for (const prod of productsData) {
    const existing = await prisma.product.findFirst({ where: { name: prod.name } });
    if (!existing) {
      const created = await prisma.product.create({ data: prod });
      await prisma.review.create({
        data: {
          rating: 5,
          comment: `Build quality on the ${created.name} exceeded expectations. Fast delivery too!`,
          userId: demoUser.id,
          productId: created.id,
        },
      });
    }
  }

  console.log('Seed completed: Demo user (alex@aura.store / DemoPass123!) and 8 products created.');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
