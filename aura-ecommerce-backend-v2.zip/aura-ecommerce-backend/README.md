# AURA E-Commerce Backend (NestJS + PostgreSQL + Prisma)

Dedicated RESTful backend API for the AURA E-Commerce Storefront.

## Quick Start

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Start PostgreSQL (via Docker or local Postgres):**
   ```bash
   docker-compose up -d
   cp .env.example .env
   ```

3. **Run Prisma Migrations & Seed Storefront Products:**
   ```bash
   npx prisma generate
   npx prisma migrate dev --name init
   npm run prisma:seed
   ```

4. **Start the NestJS Server:**
   ```bash
   npm run start:dev
   ```

5. **Open Interactive Swagger API Docs:**
   Visit `http://localhost:3000/api/docs`
