function renderProfile() {
  $('profile-card').innerHTML = `${picture(me, 96)}<h2 class="h3 mt-3">${safe(me.name)}</h2><p class="text-primary">@${me.id}</p><p>${safe(me.bio)}</p><dl class="mb-0"><dt>City</dt><dd>${safe(me.city)}</dd><dt>Education</dt><dd>${safe(me.study)}</dd><dt>Interests</dt><dd>${safe(me.interest)}</dd><dt>Friends</dt><dd>${me.friends.length}</dd></dl>`;
  $('friends-heading').textContent = `My friends (${me.friends.length})`;
  const ratings = [{ value: 1, label: 'Stupid', icon: '🙃' }, { value: 2, label: 'Cool', icon: '😎' }, { value: 3, label: 'Trustworthy', icon: '🤝' }];
  $('friend-list').innerHTML = friendUsers().map(member => {
    const chosen = data.ratings[me.id + ':' + member.id];
    return `<div class="col-md-6"><article class="bg-white border-top border-info border-3 rounded-4 p-4 shadow-sm h-100"><div class="d-flex align-items-center gap-3 mb-3">${picture(member)}<div><h3 class="h5 mb-1">${safe(member.name)}</h3><span class="small text-secondary">${safe(member.interest)}</span></div></div><fieldset><legend class="fs-6">Your rating</legend><div class="d-flex flex-wrap gap-2">${ratings.map(rating => `<button type="button" class="btn btn-sm ${chosen === rating.value ? 'btn-primary' : 'btn-outline-secondary'}" data-friend="${member.id}" data-rating="${rating.value}" aria-pressed="${chosen === rating.value}" title="${rating.value}: ${rating.label}">${rating.icon} ${rating.value} · ${rating.label}</button>`).join('')}</div></fieldset><a class="btn btn-link text-primary px-0 mt-2" href="messages.html?to=${member.id}">Send a private note →</a></article></div>`;
  }).join('') || `<div class="col-12">${empty('Your circle is empty. Visit People to invite someone.')}</div>`;
}

function setupProfile() {
  renderProfile();
  $('friend-list').addEventListener('click', event => {
    const button = event.target.closest('button[data-rating]');
    if (!button) return;
    data.ratings[me.id + ':' + button.dataset.friend] = Number(button.dataset.rating);
    if (saveData()) { renderProfile(); showNotice('Friend rating saved.'); }
  });
}

