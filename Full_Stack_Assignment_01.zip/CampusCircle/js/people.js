function renderPeople() {
  const incoming = data.requests.filter(request => request.to === me.id);
  $('incoming').innerHTML = incoming.map(request => `<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 border-top py-3"><span>${safe(user(request.from).name)} would like to connect.</span><div class="d-flex gap-2"><button class="btn btn-sm btn-primary" data-action="accept" data-id="${request.from}">Accept</button><button class="btn btn-sm btn-outline-secondary" data-action="decline" data-id="${request.from}">Decline</button></div></div>`).join('') || '<p class="text-secondary mb-0">No invitations waiting right now.</p>';
  const search = $('people-search').value.trim().toLowerCase();
  const members = data.users.filter(member => member.id !== me.id && (member.name + ' ' + member.interest).toLowerCase().includes(search));
  $('people-list').innerHTML = members.map(member => {
    const pending = data.requests.some(request => request.from === me.id && request.to === member.id);
    const received = data.requests.some(request => request.from === member.id && request.to === me.id);
    const friend = me.friends.includes(member.id);
    const ignoring = me.ignore.includes(member.id);
    let control = `<button class="btn btn-primary btn-sm" data-action="invite" data-id="${member.id}">Invite friend</button>`;
    if (friend) control = '<span class="badge text-bg-primary">Already friends</span>';
    else if (pending) control = '<span class="badge text-bg-secondary">Invitation sent</span>';
    else if (received) control = '<span class="badge text-bg-warning">Invitation waiting above</span>';
    return `<div class="col-md-6 col-xl-4"><article class="bg-white rounded-4 border-top border-primary border-3 p-4 shadow-sm h-100"><div class="d-flex align-items-center gap-3 mb-3">${picture(member)}<div><h2 class="h5 mb-1">${safe(member.name)}</h2><p class="small text-secondary mb-0">${safe(member.city)}</p></div></div><p>${safe(member.interest)}</p><div class="d-flex flex-wrap align-items-center gap-2 mb-3">${control}<a class="btn btn-outline-primary btn-sm" href="messages.html?to=${member.id}">Message</a></div><button class="btn btn-sm btn-outline-secondary" data-action="ignore" data-id="${member.id}" aria-pressed="${ignoring}">${ignoring ? 'Remove from ignore list' : 'Ignore friend requests'}</button><p class="small text-secondary mt-2 mb-0">${ignoring ? 'You are ignoring invitations from this member.' : 'Ignoring prevents their invitations from reaching you.'}</p></article></div>`;
  }).join('') || `<div class="col-12">${empty('No members match your search.')}</div>`;
}

function handlePeopleClick(event) {
  const button = event.target.closest('button[data-action]');
  if (!button) return;
  const member = user(button.dataset.id);
  const action = button.dataset.action;
  let message = '';
  if (action === 'invite') {
    // Important: check the recipient's ignore list, not just the sender's list.
    if (member.ignore.includes(me.id)) return showNotice('Request not sent: this member is ignoring your friend requests.', 'warning');
    if (me.ignore.includes(member.id)) return showNotice('Remove this member from your ignore list before inviting them.', 'warning');
    if (me.friends.includes(member.id) || data.requests.some(r => (r.from === me.id && r.to === member.id) || (r.from === member.id && r.to === me.id))) return;
    data.requests.push({ from: me.id, to: member.id });
    message = 'Friend invitation sent.';
  } else if (action === 'accept' || action === 'decline') {
    const request = data.requests.find(r => r.from === member.id && r.to === me.id);
    if (!request) return;
    if (action === 'accept') {
      if (me.ignore.includes(member.id) || member.ignore.includes(me.id)) return showNotice('This invitation cannot be accepted while either member is ignoring the other.', 'warning');
      if (!me.friends.includes(member.id)) me.friends.push(member.id);
      if (!member.friends.includes(me.id)) member.friends.push(me.id);
      message = `You and ${member.name} are now friends.`;
    } else message = 'Invitation declined.';
    data.requests = data.requests.filter(r => r !== request);
  } else if (action === 'ignore') {
    if (me.ignore.includes(member.id)) {
      me.ignore = me.ignore.filter(id => id !== member.id);
      message = 'Member removed from your ignore list.';
    } else {
      me.ignore.push(member.id);
      data.requests = data.requests.filter(r => !((r.from === member.id && r.to === me.id) || (r.from === me.id && r.to === member.id)));
      message = 'Member added to your ignore list. Any pending invitations between you were removed.';
    }
  }
  if (saveData()) { renderPeople(); showNotice(message); }
}

