// Contact buttons and the mobile dropdown select the same conversation.
function renderContacts() {
  $('contact-list').innerHTML = data.users.filter(member => member.id !== me.id).map(member => {
    const selected = member.id === $('recipient').value;
    const history = data.messages.filter(message =>
      (message.from === me.id && message.to === member.id) ||
      (message.from === member.id && message.to === me.id));
    const last = history[history.length - 1];
    const preview = last ? last.text.slice(0, 32) + (last.text.length > 32 ? '…' : '') : 'Start a conversation';
    return `<button type="button" data-contact="${member.id}" aria-pressed="${selected}" class="btn w-100 text-start p-3 mb-1 rounded-3 ${selected ? 'bg-primary-subtle border-primary-subtle' : 'btn-light border-0'}"><span class="d-flex align-items-center gap-3">${picture(member, 40)}<span class="text-break"><strong class="d-block small">${safe(member.name)}</strong><span class="small text-secondary">${safe(preview)}</span></span></span></button>`;
  }).join('');
}

function renderConversation() {
  const recipient = user($('recipient').value);
  $('conversation-header').innerHTML = `<div class="d-flex align-items-center gap-3">${picture(recipient, 48)}<div><h2 id="conversation-title" class="h6 fw-semibold mb-1">${safe(recipient.name)}</h2><p class="small text-white mb-0">${me.friends.includes(recipient.id) ? 'Your friend' : 'CampusCircle member'} · Last login ${ago(recipient.lastLogin)}</p></div></div>`;
  const messages = data.messages.filter(message =>
    (message.from === me.id && message.to === recipient.id) || (message.from === recipient.id && message.to === me.id));
  messages.sort((a, b) => a.created - b.created);
  $('conversation').innerHTML = messages.map(message => `<article class="p-3 rounded-4 ${message.from === me.id ? 'bg-primary text-white align-self-end ms-5' : 'bg-white border border-light-subtle align-self-start me-5'}"><strong class="small">${message.from === me.id ? 'You' : safe(recipient.name)}</strong><p class="my-2 text-break">${safe(message.text).replace(/\n/g, '<br>')}</p><time class="small ${message.from === me.id ? 'text-white' : 'text-secondary'}" datetime="${new Date(message.created).toISOString()}">${new Date(message.created).toLocaleString()}</time></article>`).join('') || `<div class="text-center py-5">${picture(recipient, 64)}<h3 class="h5 mt-3">Start with hello.</h3><p class="text-secondary small">Your first message to ${safe(recipient.name.split(' ')[0])} could make their day.</p></div>`;
  renderContacts();
}

function setupMessages() {
  $('recipient').innerHTML = data.users.filter(member => member.id !== me.id).map(member => `<option value="${member.id}">${safe(member.name)}${me.friends.includes(member.id) ? ' · friend' : ' · member'}</option>`).join('');
  const requested = new URLSearchParams(location.search).get('to');
  if (user(requested) && requested !== me.id) $('recipient').value = requested;
  renderConversation();
  $('recipient').addEventListener('change', renderConversation);
  $('contact-list').addEventListener('click', event => {
    const button = event.target.closest('button[data-contact]');
    if (!button) return;
    $('recipient').value = button.dataset.contact;
    renderConversation();
  });
  $('message-form').addEventListener('submit', event => {
    event.preventDefault();
    const text = $('message-text').value.trim();
    if (!text) return showNotice('Write a message before sending.', 'danger');
    data.messages.push({ from: me.id, to: $('recipient').value, text, created: Date.now() });
    if (saveData()) {
      $('message-text').value = '';
      renderConversation();
      showNotice('Private message sent.');
    }
  });
}

