/* CampusCircle: a front-end assignment using plain JavaScript and Bootstrap.
   All accounts and activity are simulated. No fetch, API, or database is used. */
const DATA_KEY = 'campuscircle-zunuran-data-v1';
const LOGIN_KEY = 'campuscircle-zunuran-login-v1';
const page = document.body.dataset.page;
function $(id) {
  return document.getElementById(id);
}
let data;
let me;

// Each member owns an ignore list. A recipient's list controls incoming requests.
function starterData() {
  const now = Date.now();
  return {
    users: [
      { id: 'zunuran', name: 'Zunuran', city: 'Islamabad', study: 'BS Computer Science', interest: 'Coding & photography', bio: 'Learning to build useful things, one small project at a time.', friends: ['ayesha', 'ali', 'sara'], ignore: [], lastLogin: now - 900000 },
      { id: 'ayesha', name: 'Ayesha Khan', city: 'Rawalpindi', study: 'Computer Science student', interest: 'Design & reading', bio: 'Good books, new ideas, and a cup of tea.', friends: ['zunuran', 'ali'], ignore: [], lastLogin: now - 120000 },
      { id: 'ali', name: 'Ali Ahmed', city: 'Islamabad', study: 'Software Engineering student', interest: 'Cricket & coding', bio: 'Always ready for a cricket match or a coding challenge.', friends: ['zunuran', 'ayesha'], ignore: [], lastLogin: now - 1500000 },
      { id: 'sara', name: 'Sara Malik', city: 'Lahore', study: 'Design student', interest: 'Art & hiking', bio: 'Collecting sketches and weekend memories.', friends: ['zunuran'], ignore: [], lastLogin: now - 4200000 },
      { id: 'bilal', name: 'Bilal Raza', city: 'Karachi', study: 'Business student', interest: 'Travel & music', bio: 'Finding a new song for every journey.', friends: [], ignore: ['zunuran'], lastLogin: now - 7200000 },
      { id: 'zoya', name: 'Zoya Noor', city: 'Islamabad', study: 'Computer Science student', interest: 'Robotics & games', bio: 'Making small robots and meeting curious people.', friends: [], ignore: [], lastLogin: now - 2400000 }
    ],
    posts: [
      { id: 'p1', author: 'ayesha', text: 'Finished my first website layout today! Small progress still counts.', created: now - 600000, audience: 'all', recipients: [], likes: ['ali'], dislikes: [] },
      { id: 'p2', author: 'ali', text: 'Anyone up for a cricket match after class tomorrow?', created: now - 2700000, audience: 'all', recipients: [], likes: ['ayesha'], dislikes: [] },
      { id: 'p3', author: 'sara', text: 'A quiet walk and a fresh page in my sketchbook. A good way to end the week.', created: now - 5400000, audience: 'all', recipients: [], likes: [], dislikes: [] }
    ],
    requests: [],
    ratings: {},
    messages: [{ from: 'ayesha', to: 'zunuran', text: 'Hi Zunuran! How is your web assignment going?', created: now - 300000 }]
  };
}

function showNotice(message, type = 'primary') {
  $('notice').textContent = message;
  $('notice').className = 'alert alert-' + type;
}

function saveData() {
  try {
    localStorage.setItem(DATA_KEY, JSON.stringify(data));
    return true;
  } catch (error) {
    showNotice('Your browser could not save this change. Allow local storage or free some browser space.', 'danger');
    return false;
  }
}

// Escape text before inserting it into HTML, so typed HTML stays ordinary text.
function safe(value) {
  return String(value).replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[character]));
}
function user(id) { return data.users.find(member => member.id === id); }
function picture(member, size = 48) {
  return `<img src="images/${member.id}.svg" width="${size}" height="${size}" alt="${safe(member.name)} profile picture" class="rounded-circle flex-shrink-0">`;
}
function ago(time) {
  const minutes = Math.max(0, Math.floor((Date.now() - time) / 60000));
  if (minutes < 1) return 'just now';
  if (minutes < 60) return `${minutes} min ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours} hour${hours === 1 ? '' : 's'} ago`;
  const days = Math.floor(hours / 24);
  return `${days} day${days === 1 ? '' : 's'} ago`;
}
function empty(text) { return `<p class="text-secondary bg-white rounded-3 p-3 border mb-0">${text}</p>`; }
function friendUsers() { return me.friends.map(user).filter(Boolean); }

