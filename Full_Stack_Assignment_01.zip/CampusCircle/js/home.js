function renderHome() {
  $('welcome').textContent = `Welcome back, ${me.name}. Here's what your friends have shared.`;
  const friends = friendUsers().sort((a, b) => b.lastLogin - a.lastLogin);
  const friendColors = ['bg-white border-primary'];
  $('recent-friends').innerHTML = friends.map((member, index) => `<div class="col-12"><div class="d-flex gap-3 align-items-center border-start border-4 rounded-4 p-3 shadow-sm h-100 ${friendColors[index % friendColors.length]}">${picture(member)}<div><strong>${safe(member.name)}</strong><div class="text-secondary small">Last login: ${ago(member.lastLogin)}</div></div></div></div>`).join('') || `<div class="col-12">${empty('No friends yet. Visit People to send an invitation.')}</div>`;
  $('audience-friends').innerHTML = friends.map(member => `<div class="form-check"><input class="form-check-input" type="checkbox" name="share-with" id="share-${member.id}" value="${member.id}"><label class="form-check-label" for="share-${member.id}">${safe(member.name)}</label></div>`).join('') || '<p>No friends to select yet.</p>';
  renderFeed();
}

function renderFeed() {
  // Selected updates are visible only to their author and chosen friends.
  const visiblePosts = data.posts.filter(post => post.author === me.id ||
    (me.friends.includes(post.author) && (post.audience === 'all' || post.recipients.includes(me.id))));
  visiblePosts.sort((a, b) => b.created - a.created);
  $('feed').innerHTML = visiblePosts.map(post => {
    const author = user(post.author);
    const audience = post.audience === 'all' ? 'All friends' :
      (post.author === me.id ? 'Only: ' + post.recipients.map(id => user(id).name).join(', ') : 'Selected friends');
    return `<div class="col-12"><article class="bg-white border-top border-primary border-3 rounded-4 p-4 shadow-sm h-100 d-flex flex-column"><div class="d-flex gap-2 align-items-center">${picture(author, 40)}<div><h3 class="h6 mb-1">${safe(author.name)}</h3><p class="small text-secondary mb-0">Last login: ${ago(author.lastLogin)}</p></div></div><p class="my-4 text-break flex-grow-1">${safe(post.text).replace(/\n/g, '<br>')}</p><p class="small text-secondary mb-3">Posted ${ago(post.created)} · ${safe(audience)}</p><div class="d-flex flex-wrap gap-2"><button class="btn rounded-pill px-3 btn-sm ${post.likes.includes(me.id) ? 'btn-primary' : 'btn-outline-primary'}" data-action="like" data-id="${post.id}" aria-pressed="${post.likes.includes(me.id)}">👍 Like <span>${post.likes.length}</span></button><button class="btn rounded-pill px-3 btn-sm ${post.dislikes.includes(me.id) ? 'btn-dark' : 'btn-outline-secondary'}" data-action="dislike" data-id="${post.id}" aria-pressed="${post.dislikes.includes(me.id)}">👎 Dislike <span>${post.dislikes.length}</span></button></div></article></div>`;
  }).join('') || `<div class="col-12">${empty('No updates yet. Share the first note or connect with a friend.')}</div>`;
}

function setupHome() {
  renderHome();
  $('audience').addEventListener('change', () => $('audience-box').classList.toggle('d-none', $('audience').value !== 'selected'));
  $('post-form').addEventListener('submit', event => {
    event.preventDefault();
    const text = $('post-text').value.trim();
    const recipients = Array.from(document.querySelectorAll('[name="share-with"]:checked')).map(box => box.value);
    if (!text) return showNotice('Please write something before sharing.', 'danger');
    if (!me.friends.length) return showNotice('Add a friend before sharing an update.', 'warning');
    if ($('audience').value === 'selected' && !recipients.length) return showNotice('Choose at least one friend for this update.', 'danger');
    data.posts.push({ id: 'p' + Date.now(), author: me.id, text, created: Date.now(), audience: $('audience').value, recipients, likes: [], dislikes: [] });
    if (saveData()) {
      $('post-form').reset();
      $('audience-box').classList.add('d-none');
      renderFeed();
      showNotice('Your update has been shared with the chosen audience.');
    }
  });
  $('feed').addEventListener('click', event => {
    const button = event.target.closest('button[data-action]');
    if (!button) return;
    const post = data.posts.find(item => item.id === button.dataset.id);
    const chosen = button.dataset.action === 'like' ? 'likes' : 'dislikes';
    const other = chosen === 'likes' ? 'dislikes' : 'likes';
    // One reaction per user: click again to remove; switch to replace it.
    if (post[chosen].includes(me.id)) post[chosen] = post[chosen].filter(id => id !== me.id);
    else {
      post[chosen].push(me.id);
      post[other] = post[other].filter(id => id !== me.id);
    }
    if (saveData()) renderFeed();
  });
}

