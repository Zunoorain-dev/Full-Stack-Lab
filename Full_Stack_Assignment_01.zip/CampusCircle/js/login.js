function setupLogin() {
  // A shortcut for trying the existing demo account; this is not registration.
  $('demo-login').addEventListener('click', () => {
    $('username').value = 'zunuran';
    $('password').value = 'demo123';
    $('login-form').requestSubmit();
  });
  $('login-form').addEventListener('submit', event => {
    event.preventDefault();
    const member = user($('username').value.trim().toLowerCase());
    if (!member || $('password').value !== 'demo123') {
      showNotice('Incorrect username or password. Try zunuran and demo123.', 'danger');
      return;
    }
    member.lastLogin = Date.now();
    if (!saveData()) return;
    try {
      localStorage.setItem(LOGIN_KEY, member.id);
      location.href = 'home.html';
    } catch (error) {
      showNotice('Sign-in needs browser storage. Please allow it and try again.', 'danger');
    }
  });
  $('reset-demo').addEventListener('click', () => {
    if (!confirm('Reset all demo posts, messages, ratings, and requests?')) return;
    data = starterData();
    if (saveData()) {
      localStorage.removeItem(LOGIN_KEY);
      showNotice('Demo data reset. Sign in to start again.');
    }
  });
}

