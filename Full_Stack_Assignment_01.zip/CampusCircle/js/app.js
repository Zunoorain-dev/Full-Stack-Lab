function start() {
  try {
    const saved = localStorage.getItem(DATA_KEY);
    data = saved ? JSON.parse(saved) : starterData();
    if (!Array.isArray(data.users) || !Array.isArray(data.posts) || !Array.isArray(data.messages) || !Array.isArray(data.requests) || !data.ratings) throw new Error('Invalid saved data');
    if (!saved && !saveData()) return;
    me = user(localStorage.getItem(LOGIN_KEY));
  } catch (error) {
    data = starterData();
    showNotice('Saved demo data could not be read. Open the login page and reset the demo. If storage is disabled, allow it first.', 'danger');
    if (page === 'index') setupLogin();
    return;
  }
  if (page === 'index') { setupLogin(); return; }
  if (!me) { location.replace('index.html'); return; }
  $('account-name').textContent = me.name.split(' ')[0];
  $('logout').addEventListener('click', () => {
    localStorage.removeItem(LOGIN_KEY);
    location.href = 'index.html';
  });
  if (page === 'home') setupHome();
  if (page === 'profile') setupProfile();
  if (page === 'people') {
    renderPeople();
    $('people-search').addEventListener('input', renderPeople);
    $('people-list').addEventListener('click', handlePeopleClick);
    $('incoming').addEventListener('click', handlePeopleClick);
  }
  if (page === 'messages') setupMessages();
}
start();
